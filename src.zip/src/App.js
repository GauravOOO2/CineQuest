import './App.css';
import Body from './pages/Body';


function App() {
  

  return (
    <div className='AppContainer' >
      <Body /> 
    </div>
  );
}

export default App;
